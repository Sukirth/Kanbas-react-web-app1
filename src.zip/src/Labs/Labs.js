// import Lab3 from "./a3";

// function Labs () {

//     return (
//         <div>
//             <Lab3/>
//             <Lab4/>
//             <Lab5/>
//         </div>
//     );

// }
// export default Labs