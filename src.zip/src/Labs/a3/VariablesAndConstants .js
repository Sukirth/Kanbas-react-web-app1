function VariablesAndConstants() {
    var functionScoped = 2;
    let blockScoped = 5;
    const constant1 = functionScoped - blockScoped;
    console.log("in variables & coonst");
    return(
       <div>
          <h3>Variables and Constants</h3>
          functionScoped = { functionScoped }<br/>
          blockScoped = { blockScoped }<br/>
          constant1 = { constant1 }<br/>
       </div>
    );
 }
 export default VariablesAndConstants