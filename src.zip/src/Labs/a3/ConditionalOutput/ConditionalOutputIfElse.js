const ConditionalOutputIfElse = () => {
    //const loggedIn = true;
    const loggedIn = false;
    if(loggedIn){
        return ("You have successfully loggedIn!");
    }
    else {
        return ("Please login");
    }

}
export default ConditionalOutputIfElse