function Add({a,b}){
    return (
        <div>
            <h1>Add:</h1>
            <p>
                {a} + {b} = {a+b};
            </p>
        </div>
    );

}
export default Add;