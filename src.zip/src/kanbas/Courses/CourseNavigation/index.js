import { Link, useParams, useLocation } from "react-router-dom";
import "./index.css";

function CourseNavigation() {
  const links = ["Home", "Modules", "Piazza", "ZoomMeetings" ,"Assignments", "Quizzes" ,"Grades", "People" ];
  const { courseId } = useParams();
  const { pathname } = useLocation();
  return (
    <div className="list-group" style={{ width: 150 }}>
      <span className="wd-courseNav-spanText">202310_2_Fall_2022 Semester</span>
      {links.map((link, index) => (
        <Link
          key={index}
          to={`/Kanbas/Courses/${courseId}/${link}`}
          className={`list-group-item ${pathname.includes(link) && "active"} wd-course-nav`}>
          {link}
        </Link>
      ))}
    </div>
  );
}


export default CourseNavigation;