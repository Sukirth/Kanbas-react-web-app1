import ModuleList from "./Modulelist";

function Modules() {
    console.log("in modules screen");
  return (    
    <div>
      <h2>Modules</h2>
      <ModuleList/>
    </div>
  );
}
export default Modules;
